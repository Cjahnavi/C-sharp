﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AbstractClassDemo
{
    public abstract class absParent
    {
        public abstract void Add(int x, int y);

        public void Sub(int x, int y)
        {
            Console.WriteLine(x - y);
        }
    }

    public class absChild : absParent
    {
        public override void Add(int x, int y)
        {
            Console.WriteLine(x + y);
        }

        static void Main()
        {
            absChild obj = new absChild();
            obj.Add(10, 20);
            obj.Sub(30, 20);
        }
    }
}
