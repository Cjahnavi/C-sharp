﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AbstractClassDemo
{
    interface IMaths
    {
        void Add(int a, int b);
        void Sub(int a, int b);
        void Mul(int a, int b);
    }

    interface IMaths1
    {
        void Add(int a, int b);
        void Div(int a, int b);
    }

    class ChildMaths : IMaths, IMaths1
    {
        public void Add(int a, int b)
        {
            Console.WriteLine(a + b);
        }

        public void Sub(int a, int b)
        {
            Console.WriteLine(a - b);
        }

        public void Mul(int a, int b)
        {
            Console.WriteLine(a * b);
        }

        public void Div(int a, int b)
        {
            Console.WriteLine(a / b);
        }

        static void Main()
        {
            ChildMaths obj = new ChildMaths();
            obj.Add(10, 20);
            obj.Sub(30, 20);
            obj.Mul(10, 20);
        }

        
    }

}
