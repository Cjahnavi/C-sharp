﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MethodOverridingDemo
{
    class Program
    {
        public void Test(int a)
        {
            Console.WriteLine("Parents Overloding Method");
        }
        public virtual void Show()
        {
            Console.WriteLine("Calling Parents Show Method");
        }

        public void Hide()
        {
            Console.WriteLine("Calling parents Hide Method");
        }
    }

    class childPgm : Program
    {
        public void Test(int a, int b)
        {
            Console.WriteLine("Childs Overloding Method");
        }

        public override void Show()
        {
            Console.WriteLine("Calling Childs Show Method");
        }

        public new void Hide()
        {            
            Console.WriteLine("Calling Child Hide Method");
        }

        public void ParentShow()
        {
            base.Show();
        }
        static void Main()
        {            
            childPgm obj = new childPgm();
            obj.Test(10);
            obj.Test(10, 20);

            obj.Show();
            obj.Hide();
            
            obj.ParentShow();

            Program objPgm;

            objPgm = obj;

            Console.WriteLine("---------------------------");
            
            objPgm.Show();      //Overriding
            objPgm.Hide();      //MethodHiding

                        
        }
    }
}
