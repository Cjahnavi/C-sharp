﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PropertiesDemo
{
    public class Employee
    {
               
        //Property
        int _id;
        public int ID
        {
            get { return _id; }
            set { _id = value; }
        }

        int _balance = 1000;
        public int Balance
        {
            get { return _balance; }
            set {
                if(_balance > 500)
                {
                    _balance = value;
                }
            }
        }
    }

    class ChildEmp
    {
        static void Main()
        {
            Employee emp = new Employee();
            int id;
            //id = emp.GetID();
            
            emp.ID = 10;
            id = emp.ID;

            Console.WriteLine(id);

            Console.WriteLine("Initial Balance " + emp.Balance);

            emp.Balance = 400;
            Console.WriteLine("Currrent Balance " + emp.Balance);

            emp.Balance = 700;
            Console.WriteLine("Current Balance after setting " + emp.Balance);
        }
    }
}
